"""
Pacote 'rich' — demonstra funcionalidades da biblioteca Rich.
Contém módulos para layout, painel, progresso e estilo.
"""
