# Exercício - Biblioteca Rich

Exercício de uso da biblioteca [Rich](https://rich.readthedocs.io/).

## Requisitos
- Python 3.10+
- Biblioteca `rich`

## Instalação
`!/bin/bash`
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
pip install rich

## Exemplo de Uso (Comandos):

python main.py "Olá Mundo com Painel" -m painel -f painel_padrao

python main.py "texto.txt" -a -m estilo -f texto_colorido

python main.py "Processando dados..." -m progresso -f barra_progresso

python main.py "Layout testando..." -m layout -f mostrar_layout
